BeagleBadge U-Boot SD / OSPI Update Bundle
==========================================

Build
-----
U-Boot: 2026.01-S2549-P6f1d-Hfc20-V19c2-B5da4-R448a
Hardware: BeagleBadge / AM62L3
Build date: July 27, 2026

This bundle updates U-Boot only. It is not a complete Armbian SD-card
image and does not contain Linux or Zephyr. Start with an existing,
bootable BeagleBadge Armbian SD card.

Files that must be kept together
--------------------------------
tiboot3.bin
tispl.bin
u-boot.img

Do not mix these files with files from another build.

Install the files on an SD card
-------------------------------
1. Copy tiboot3.bin, tispl.bin, and u-boot.img files to a FAT partitioned SD card. FAT = FAT16
2. Insert the card into the BeagleBadge and power it on using the board's
   SD-boot/reset method if OSPI is currently the normal boot source.

The boot menu should show these maintenance entries when U-Boot itself
was loaded from SD:

  USB Storage Mode (SD card)
  Update OSPI U-Boot from SD (advanced)

Flash this U-Boot build to OSPI
-------------------------------
1. Confirm the badge was booted from the updated SD card. The menu entry
   "Update OSPI U-Boot from SD (advanced)" is deliberately hidden when
   U-Boot was loaded from OSPI.
2. Use the joystick to highlight that entry and press Select.
3. The updater loads and size-checks all three files before changing
   flash. It updates u-boot.img first, tispl.bin second, and tiboot3.bin
   last. Every write is read back and compared with the source data.

After all three files verify successfully, the badge prints a success
   message and resets automatically.

On a subsequent OSPI boot, the OSPI-update entry will be absent by
   design. Linux, Zephyr, USB Storage Mode, and the recovery console
   remain available.

If the OSPI-update entry is missing before flashing, power off and force
one boot from SD. Its absence means this U-Boot instance started from
OSPI; it does not mean the files are missing from the card.
