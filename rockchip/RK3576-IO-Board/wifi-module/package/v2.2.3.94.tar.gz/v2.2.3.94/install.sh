#!/bin/bash

cp -vf ./scripts/* /root
cp -vf ./tools/ioctl_app /usr/bin
cp -vf ./configs/wq_wlan_settings.ini /lib/firmware/
cp -rvf ./driver/wq_wlan.ko /lib/modules/6.1.115-vendor-rk35xx/
cp -rvf ./firmwares/wq9201* /lib/firmware/

depmod -a

echo "done here, please reboot your device to load the driver"
