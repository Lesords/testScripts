#!/bin/bash

SCRIPT_DIR="$(dirname "$(readlink -f "$0")")"

# 查看当前频率
echo "current NPU freq: $(cat /sys/class/devfreq/27700000.npu/cur_freq)"

export LD_LIBRARY_PATH=${SCRIPT_DIR}/lib

echo "starting benchmark with 1 threads, each running 1000000 iterations..."

# core_mask: 0=自动, 1=Core0, 2=Core1, 3=Core0+Core1
${SCRIPT_DIR}/rknn_benchmark ${SCRIPT_DIR}/yolo11n_rk3588_int8.rknn "" 1000000 0
