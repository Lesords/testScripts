#!/bin/bash

SCRIPT_DIR="$(dirname "$(readlink -f "$0")")"

# 锁定 NPU 最高频率
MAX_FREQ=$(cat /sys/class/devfreq/27700000.npu/available_frequencies | tr ' ' '\n' | sort -n | tail -1)
echo userspace > /sys/class/devfreq/27700000.npu/governor
echo $MAX_FREQ > /sys/class/devfreq/27700000.npu/min_freq
echo $MAX_FREQ > /sys/class/devfreq/27700000.npu/max_freq

# 确认频率已锁定
echo "current NPU freq: $(cat /sys/class/devfreq/27700000.npu/cur_freq)"

export LD_LIBRARY_PATH=${SCRIPT_DIR}/lib

echo "starting benchmark with 2 threads, each running 1000 iterations..."

# core_mask: 0=自动, 1=Core0, 2=Core1, 3=Core0+Core1, 7=Core0+Core1+Core2
${SCRIPT_DIR}/rknn_benchmark ${SCRIPT_DIR}/yolo11n_rk3588_int8.rknn "" 1000000 1 &
${SCRIPT_DIR}/rknn_benchmark ${SCRIPT_DIR}/yolo11n_rk3588_int8.rknn "" 1000000 1 &
${SCRIPT_DIR}/rknn_benchmark ${SCRIPT_DIR}/yolo11n_rk3588_int8.rknn "" 1000000 2 &
${SCRIPT_DIR}/rknn_benchmark ${SCRIPT_DIR}/yolo11n_rk3588_int8.rknn "" 1000000 2 &
${SCRIPT_DIR}/rknn_benchmark ${SCRIPT_DIR}/yolo11n_rk3588_int8.rknn "" 1000000 4 &
${SCRIPT_DIR}/rknn_benchmark ${SCRIPT_DIR}/yolo11n_rk3588_int8.rknn "" 1000000 4 &
