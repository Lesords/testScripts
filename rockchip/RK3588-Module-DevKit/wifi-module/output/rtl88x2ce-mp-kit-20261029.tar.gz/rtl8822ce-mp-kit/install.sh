#!/bin/sh
# rtl8822ce-mp-kit 安装脚本 — RTL8822CE WiFi/BT 定频(MP)部署物
# 板: reComputer Industrial RK3588 | 目标内核: 6.1.172-vendor-seeed-rk3588 (88x2ce.ko vermagic)
# 用法(板端, root):  sh install.sh [--blacklist-mainline] [--force]
set -e
cd "$(dirname "$0")"
BLACKLIST=0; FORCE=0
for a in "$@"; do
  case "$a" in
    --blacklist-mainline) BLACKLIST=1 ;;
    --force) FORCE=1 ;;
    *) echo "unknown arg: $a"; exit 1 ;;
  esac
done
echo "== rtl8822ce-mp-kit install =="
KREL=$(uname -r)
echo "kernel: $KREL"
echo "-- 1/5 检查文件 --"
for f in files/88x2ce.ko files/rtwpriv files/rtlbtmp files/mp_rtl8822c_fw files/mp_rtl8822c_config; do
  [ -f "$f" ] || { echo "缺文件: $f"; exit 1; }
done
echo "   5 个文件齐全"
echo "-- 2/5 vermagic 校验 --"
VM=$(modinfo files/88x2ce.ko 2>/dev/null | awk -F': *' '/^vermagic/{print $2}')
echo "   ko vermagic : $VM"
echo "   板内核      : $KREL"
case "$VM" in
  "$KREL "*) echo "   匹配 OK" ;;
  *) if [ "$FORCE" = 1 ]; then echo "   !! 不匹配, --force 强制继续"; else
       echo "   !! 不匹配, 拒绝安装 (内核升级后请重编驱动)"
       exit 1; fi ;;
esac
echo "-- 3/5 安装 WiFi 定频驱动 --"
install -D -m 644 files/88x2ce.ko "/lib/modules/$KREL/extra/88x2ce.ko"
depmod -a "$KREL"
if [ "$BLACKLIST" = 1 ]; then
  printf "blacklist rtw88_8822ce\n" > /etc/modprobe.d/blacklist-rtw88-8822ce.conf
  echo "   已写 blacklist (开机不自动加载主线驱动)"
fi
echo "   后续用法: rmmod rtw88_8822ce && modprobe 88x2ce"
echo "-- 4/5 安装工具 --"
install -D -m 755 files/rtwpriv  /usr/local/bin/rtwpriv
install -D -m 755 files/rtlbtmp  /usr/local/bin/rtlbtmp
echo "   rtwpriv / rtlbtmp -> /usr/local/bin/"
echo "-- 5/5 安装 BT MP 固件(文件名硬编码,不可改名) --"
install -D -m 644 files/mp_rtl8822c_fw     /lib/firmware/mp_rtl8822c_fw
install -D -m 644 files/mp_rtl8822c_config /lib/firmware/mp_rtl8822c_config
echo
echo "== 安装完成 =="
echo "WiFi 定频: rtwpriv <网卡名> mp_start   (网卡名用 ip link 查, udev 会改名为 wlP2p33s0)"
echo "BT  定频: rtlbtmp -> enable usb:/dev/hci0  (先 systemctl stop bluetooth, enable 异步等 Success)"
echo "完整步骤: 见上位机 wifi-module/README.md"
